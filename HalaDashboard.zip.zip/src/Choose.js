
function Choose () {
    return (
<div> 
<div className="container">
      <section className="why-us">
        <h1>Why choose bloom bank?</h1>
        <p
          >We leverage open banking to turn your bank account into your
          financial hub.<br />Control your finances like never before.</p
        >
      </section>

     
  </div> 
      <section className="features-section">
        <div className="feature-item">
          <img src="" alt="" />
          <h1>Online Banking</h1>
          <p
            >Our modern web and mobile<br />
            applications allow you to keep<br />
            track of your finances whereever<br />
            you are in the world.</p
          >
        </div>
        <div className="feature-item">
          <img src="" alt="" />
          <h1>Simple Budgeting</h1>
          <p
            >See exactly where your money<br />
            goes every month.Recieve <br />
            notifications when you're close to<br />
            hitting your limits. 
          </p> 
          </div>

        <div className="feature-item">
          <img src="" alt="" />
          <h1>Fast Onboarding</h1>
          <p
            >We don't do branches.Open your<br />
            accound minutes online and start<br />
            taking controll of your finances<br />
            right away.
            </p>
        </div>

        <div className="feature-item">
          <img src="" alt="" />
          <h1>Open API</h1>
          <p
            >Manage your savings, investments,<br />
            pension and much more from one<br />
            account.Tracking your money has<br />
            never been easier.
            </p >

        </div>
        </section>
        </div>

        );
        }
        export default Choose;
import React from 'react';
import axios from 'axios';
import { Link }from 'react-router-dom';
import { Navigate } from 'react-router-dom';
import './index.css'; 


  class Loginbox extends React.Component{

    state={
        users:[],
        useremail:"",
        userpassword:"",
        accountMessage:""
        
    }

    componentDidMount(){
        axios.get('https://jsonplaceholder.typicode.com/users')
        .then(
            res=>{
                let tempData = res.data;
                this.setState({ users:tempData });
            }    
        );
    }

    authenticateUser = (e)=>{
        e.preventDefault();
        let flag=0;
        this.state.users.forEach(user => {
            if(user.email==this.state.useremail && user.address.suite==this.state.userpassword){
                flag=1;
            }
        });
        if(flag==1){
            this.setState({accountMessage:"Valid details"});
            window.location.href = '/dashboard';
            }
        else{
            this.setState({accountMessage:"Invalid details"});
            }   
    }


  render (
     ){
        return (
        <section>
        
    <div className="wrapper">
      <div className="title">sign in</div>
      <form action="#">
        <div className="field">
          <input type="text" required onChange={(e)=>{
                         this.setState({useremail:e.target.value})
                     }} /> 
          <label>Email Address</label>
        </div>
        <div className="field">
          <input type="password" required onChange={(e)=>{
                         this.setState({userpassword:e.target.value})
                     }} />
          <label>Password</label>
        </div>
        <div className="content">
          <div className="checkbox">
            <input type="checkbox" id="remember-me"/>
            <label htmlFor="remember-me">Remember me</label>
          </div>
          <div className="pass-link"><a href="#">Forgot password?</a> </div>
        </div>
        <div className="field">
          <Link to ="/signup"><input type="submit" value="Login"/> </Link>
        </div>
        <div className="signup-link">Not a member? <a href="pages/signup.html">Signup now</a></div>
      </form>
    </div>
        </section>
        );
        }
}
export default Loginbox;
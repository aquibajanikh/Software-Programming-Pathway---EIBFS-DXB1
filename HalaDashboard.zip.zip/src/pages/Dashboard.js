import Header from "../components/Header";
import Leftmenu from "../components/Leftmenu";
import Dashroard from "../components/Dashroad";
import Currency from "../components/Currency";
import Notification from "../components/Notification";
import Color from './../components/Color';
import Footer from "../Footer";

function Dashboard () {
    return(
        <>
        <Leftmenu/>
        <Header/>
        <Dashroard/>
        <Notification/>
        <Currency/>
        <Color/>
        <Footer/>
        </>
        
    );
} 

export default Dashboard;